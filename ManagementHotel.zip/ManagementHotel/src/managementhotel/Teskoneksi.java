/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package managementhotel;

/**
 *
 * @author INSTIKI
 */
public class Teskoneksi {
    public static void main(String[] args) {
        java.sql.Connection conn = dbkoneksi.koneksi();
        if (conn != null) {
            System.out.println("✅ Koneksi ke database berhasil!");
        } else {
            System.out.println("❌ Koneksi gagal!");
    
}
    }
}